# Restaurant-Management-System

## Features !
 - Intuitive user interface
 - Desktop application
 - File Based Data storage
 - Easy to modify design
 - Multiple modules
    - Basic Authentication  
    - Item Management 
    - Order Management
    - Labour Management
    - Billing Management


## Authentication
There is no standard authentication has been added yet. Currently, it is hardcoded.

```
Username : shahin
Password : shahin
```
